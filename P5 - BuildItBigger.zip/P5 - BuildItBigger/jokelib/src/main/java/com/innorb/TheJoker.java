package com.innorb;

public class TheJoker
{
    public String crackJoke() {
        return "Become Pun with The Force, Anakin";
    }
}